create function pg_catalog.interval_pl_timestamptz(interval, timestamp with time zone) returns timestamp with time zone
LANGUAGE SQL
AS $$
select $2 + $1
$$;
